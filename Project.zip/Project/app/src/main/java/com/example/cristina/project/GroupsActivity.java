package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.cristina.project.adapters.StudentAdapter;
import com.example.cristina.project.model.Student;
import com.example.cristina.project.workers.StudentWorker;

import java.util.ArrayList;
import java.util.List;

public class GroupsActivity extends AppCompatActivity {


    private ListView listView;

//    public static List<Student> studentsList = new ArrayList<>();
//    public static StudentAdapter studentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);

        listView = (ListView)findViewById(R.id.studentsListView);

        //TODO: Ulterior grupele la care preda profesorul logat vor fi extrase din bd. Doar studentii vor fi extrasi momentan dintr-un json
        List<String>groupsList = new ArrayList<String>();
        groupsList.add("1074");
        groupsList.add("1075");
        groupsList.add("1070");

        ArrayAdapter<String>arrayAdapter = new ArrayAdapter<String>(this,
        android.R.layout.simple_list_item_1, groupsList);

        listView.setAdapter(arrayAdapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selected;
                selected = parent.getItemAtPosition(position).toString();

                if (selected.equals("1074")) {
                    Intent intent1 = new Intent(GroupsActivity.this, StudentsListActivity.class);
                    intent1.putExtra("KEY", "l407u");
                    startActivity(intent1);
                } else if (selected.equals("1075")) {
                    Intent intent2 = new Intent(GroupsActivity.this, StudentsListActivity.class);
                    intent2.putExtra("KEY", "6ab96");
                    startActivity(intent2);
                } else if (selected.equals("1070")) {
                    Intent intent3 = new Intent(GroupsActivity.this, StudentsListActivity.class);
                    intent3.putExtra("KEY", "vainu");
                    startActivity(intent3);
                }
            }
        });
            }

    }

