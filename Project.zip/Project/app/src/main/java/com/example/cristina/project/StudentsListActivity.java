package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.cristina.project.adapters.StudentAdapter;
import com.example.cristina.project.model.Student;
import com.example.cristina.project.workers.StudentWorker;

import java.util.ArrayList;
import java.util.List;

public class StudentsListActivity extends AppCompatActivity {

    private ListView listview;
    public static List<Student> studentsList;
    public static StudentAdapter studentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list2);

        Intent intent = getIntent();


        studentsList = StudentWorker.studentsList;
        studentAdapter = new StudentAdapter(this, studentsList);
        listview = findViewById(R.id.studListView);
        listview.setAdapter(studentAdapter);



        if(intent!=null){
            String grupa = intent.getStringExtra("KEY");
            StudentWorker worker = new StudentWorker();
            worker.execute(grupa);
        }
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Student question = studentsList.get(position);

            }
        });

       // studentsList = new ArrayList<Student>();
      //  StudentWorker.studentsList = new ArrayList<>();
    }




}
