package com.example.cristina.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.cristina.project.model.Question;
import com.example.cristina.project.model.Quiz;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class AddQuestionActivity extends AppCompatActivity {

    ImageView imageView;
    Button addQuestionButton, finishQuizButton;
    Button optAButton,optBButton, optCButton, optDButton;
    EditText questionText, optionsEditText;
    CheckBox cbA, cbB, cbC, cbD;
    public static Quiz quiz;


    public static ArrayList<Question> questionList=new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);



        quiz = new Quiz();
        quiz = CreateQuizTest.getQuiz();
        Button buttonLoadImage = (Button)findViewById(R.id.importQuestionImageButton);
        addQuestionButton = (Button)findViewById(R.id.addQuestionButton);
        finishQuizButton = (Button)findViewById(R.id.doneButton);


        optAButton = (Button)findViewById(R.id.optionAButton);
        optBButton = (Button)findViewById(R.id.optionBButton);
        optCButton=(Button)findViewById(R.id.optionCButton);
        optDButton=(Button)findViewById(R.id.optionDButton);

        optionsEditText = (EditText) findViewById(R.id.optionsEditText);
        questionText = (EditText)findViewById(R.id.questionEditText);
        imageView = (ImageView)findViewById(R.id.questionImage);

        cbA = (CheckBox)findViewById(R.id.optACheckBox);
        cbB = (CheckBox)findViewById(R.id.optBCheckBox);
        cbC = (CheckBox)findViewById(R.id.optCCheckBox);
        cbD = (CheckBox)findViewById(R.id.optDCheckBox);




        buttonLoadImage.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 0);
            }

        });

        addQuestionButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {

                Question question = new Question();


                question.text = questionText.getText().toString();
                question.image = ((BitmapDrawable)imageView.getDrawable()).getBitmap();


                if(cbA.isChecked()){
                    question.answer = optAButton.getText().toString();
                }
                if(cbB.isChecked()){
                    question.answer=optBButton.getText().toString();
                }
                if(cbC.isChecked()){
                    question.answer=optCButton.getText().toString();
                }
                if(cbD.isChecked()){
                    question.answer=optDButton.getText().toString();
                }



                questionList.add(question);
                quiz.questionList.add(question);

                imageView.setImageResource(R.drawable.noimage);
                questionText.setText("");
                optionsEditText.setText("");
                optAButton.setText("");
                optBButton.setText("");
                optCButton.setText("");
                optDButton.setText("");

                cbA.setChecked(false);
                cbB.setChecked(false);
                cbC.setChecked(false);
                cbD.setChecked(false);
            }
        });



        optAButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                optAButton.setText(optionsEditText.getText().toString());
                optionsEditText.setText("");
            }
        });

        optBButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                optBButton.setText(optionsEditText.getText().toString());
                optionsEditText.setText("");
            }
        });

        optCButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                optCButton.setText(optionsEditText.getText().toString());
                optionsEditText.setText("");
            }
        });

        optDButton.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                optDButton.setText(optionsEditText.getText().toString());
                optionsEditText.setText("");
            }
        });

    }




    public static Quiz getQuiz(){
//        quiz.questionList = questionList;
        return quiz;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK){
            Uri targetUri = data.getData();
            Bitmap bitmap;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(targetUri));
                imageView.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<Question> getList(){
        return AddQuestionActivity.questionList;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_question, menu);
        return true;
    }



    public void finishQuiz(View v){
       Intent intent = new Intent(this, TestReviewActivity.class);
       startActivity(intent);
    }




    //TODO: add functionalities for action bar options
    @Override
    public boolean onOptionsItemSelected(MenuItem item) { switch(item.getItemId()) {
        case R.id.action_delete:
            return(true);
        case R.id.action_awardPoints:
            return(true);
    }
        return(super.onOptionsItemSelected(item));
    }



}



