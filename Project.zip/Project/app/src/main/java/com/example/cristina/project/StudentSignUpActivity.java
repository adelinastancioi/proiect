package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentSignUpActivity extends AppCompatActivity {
 private EditText ed1,ed2,ed3,ed4,ed5,ed6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_sign_up);

        ed1=findViewById(R.id.firstNameEditView);
        ed2=findViewById(R.id.lastNameEditView);
        ed3=findViewById(R.id.emailEditView);
        ed4=findViewById(R.id.passwordEditView);
        ed5=findViewById(R.id.confirmPasswordEditView);
        ed6=findViewById(R.id.Grupa);



    }

    public void navigateToStudentProfile(View v) {
        /*Intent intent = new Intent(this, StudentProfile.class);
        intent.putExtra("prenume", ed1.getText().toString());
        intent.putExtra("nume", ed2.getText().toString());
        intent.putExtra("grupa", ed6.getText().toString());
        startActivity(intent);*/

        if (ed1 != null && ed2 != null && ed3 != null && ed5 != null && ed6 != null)
        {
            String cText = "Toast Message";
            int val = 1;

            //Toast.makeText(getApplicationContext(), cText, Toast.LENGTH_LONG).show();
            {
                if ("".equals(ed1.getText().toString()) || "".equals(ed2.getText().toString()) || "".equals(ed3.getText().toString()) || "".equals(ed4.getText().toString()) || "".equals(ed5.getText().toString()) ||
                        "".equals(ed6.getText().toString())
                        )
                {
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(this);
                    builder.setTitle(R.string.error_text);
                    builder.setMessage("All fields are mandatory!");
                    builder.setPositiveButton("OK", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {

                    if (isEmailValid(ed3.getText().toString().trim()) == false) {
                        AlertDialog.Builder builder =
                                new AlertDialog.Builder(this);
                        builder.setTitle(R.string.error_text);
                        builder.setMessage("Invalid Email");
                        builder.setPositiveButton("OK", null);
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        return;
                    }
                    if (isPasswdValid(ed4.getText().toString().trim()) == false) {
                        AlertDialog.Builder builder =
                                new AlertDialog.Builder(this);
                        builder.setTitle(R.string.error_text);
                        builder.setMessage("Invalid Password(Minimum 4 characters, at least one uppercase letter and one number and a special character)");
                        builder.setPositiveButton("OK", null);
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        return;
                    }
                    String u = ed4.getText().toString();
                    String p = ed5.getText().toString();
                    if ( ! u.equals( p )){
                        AlertDialog.Builder builder =
                                new AlertDialog.Builder(this);
                        builder.setTitle(R.string.error_text);
                        builder.setMessage("Not the same password as the previous one");
                        builder.setPositiveButton("OK", null);
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        return;
                    }
//                    if (ed4.getText().toString() != ed5.getText().toString() || ed4.getText().length() < 6) {
//                        return;
//                    }
                    Intent intent = new Intent(StudentSignUpActivity.this, StudentProfile.class);
                    intent.putExtra("prenume", ed1.getText().toString());
                    intent.putExtra("nume", ed2.getText().toString());
                    intent.putExtra("grupa", ed6.getText().toString());
                    startActivity(intent);
                }
            }

        }

    }

    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }
    public static boolean isPasswdValid(String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }

    }

