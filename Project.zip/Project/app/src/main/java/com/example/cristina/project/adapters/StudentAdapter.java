package com.example.cristina.project.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.cristina.project.R;
import com.example.cristina.project.model.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentAdapter extends BaseAdapter {

    List<Student> students;
    LayoutInflater layoutInflater;


    public StudentAdapter(Context context, List<Student> students){
        layoutInflater = LayoutInflater.from(context);
        this.students = students;
    }

    @Override
    public int getCount() {
        return students.size();
    }

    @Override
    public Object getItem(int position) {
        return students.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if(convertView ==  null) {
            convertView = layoutInflater.inflate(R.layout.student_item, parent,false);

        }
 try {
     TextView firstNameTextView = convertView.findViewById(R.id.fnameTxt);
     TextView lastNameTextView = convertView.findViewById(R.id.lnameTxt);
     TextView emailTextView = convertView.findViewById(R.id.emailTxt);
     TextView classTextView = convertView.findViewById(R.id.classTxt);
     TextView scoreTextView = convertView.findViewById(R.id.scoreTxt);

     Student student = students.get(position);


     firstNameTextView.setText(student.firstName);
     lastNameTextView.setText(student.lastName);
     emailTextView.setText(student.email);
     String score = new Double(student.scorMediu).toString();
     String gr = Integer.toString(student.grupa);
     scoreTextView.setText(score);
     classTextView.setText(gr);
 }
 catch(Exception e){

 }
            return convertView;

    }





}
