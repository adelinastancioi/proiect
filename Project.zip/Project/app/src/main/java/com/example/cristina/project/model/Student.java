package com.example.cristina.project.model;

public class Student {
    public String firstName;
    public String lastName;
    public String email;
    public int grupa;
    public double scorMediu;


}
