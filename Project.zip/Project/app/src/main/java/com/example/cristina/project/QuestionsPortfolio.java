package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.cristina.project.adapters.QuestionCustomAdapter;
import com.example.cristina.project.model.Question;

import java.util.ArrayList;

public class QuestionsPortfolio extends AppCompatActivity {

    ListView listview;
    private static QuestionCustomAdapter adapter;
    public static ArrayList<Question> questionArrayList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions_portfolio);

        listview = (ListView)findViewById(R.id.questionList);
        questionArrayList = AddQuestionActivity.getList();

        QuestionCustomAdapter questionAdaper = new QuestionCustomAdapter(this, questionArrayList);
        listview.setAdapter(questionAdaper);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Question question = questionArrayList.get(position);

            }
        });
    }


//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if(requestCode == 1 && resultCode == RESULT_OK) {
//            Question question =
//                    (Question) data.getSerializableExtra("quest");
//            questionArrayList.add(question);
//            if(adapter != null) {
//                adapter.notifyDataSetChanged();
//            }
//        }
//    }
}
