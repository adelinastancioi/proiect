package com.example.cristina.project.model;

import android.graphics.Bitmap;

import java.io.Serializable;

public class Question implements Serializable {


    public String text;
    public Bitmap image;
    public String answer;
    public String[] options;

    public Question(String text, Bitmap image, String[] options, String answers){
        this.text = text;
        this.image = image;
        this.options = options;
        this.answer = answers;
    }

    public String toString(){
        return this.text + "\n"+this.answer;
    }


    public Question() {
    }
}
