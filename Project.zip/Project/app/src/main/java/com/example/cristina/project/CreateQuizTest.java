package com.example.cristina.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

import com.example.cristina.project.model.Question;
import com.example.cristina.project.model.Quiz;

import java.util.ArrayList;

public class CreateQuizTest extends AppCompatActivity {
    private Button btCancel,btDone,addQuestion;
    private EditText ed1,ed2,ed3;
    private Switch sw;
    private Spinner spinner;
    private static Quiz quiz;
    private static ArrayList<Question> questionList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz_test);

        SharedPreferences sp=getApplication().getSharedPreferences("option",MODE_PRIVATE);
        SharedPreferences.Editor editor=sp.edit();
        editor.putString("key","individual");
        editor.putString("key1","group");

        ed1=findViewById(R.id.Cod);
        ed2=findViewById(R.id.Title);
        ed3=findViewById(R.id.Description);

    }




    public void setBtCancel(View view){
        Intent intent=new Intent(this,TeacherProfileActivity.class);
        startActivity(intent);
    }




    public static Quiz getQuiz(){
        return CreateQuizTest.quiz;
    }

    public void addQuestion(View view){

        if(ed1!=null && ed2!=null && ed3!=null){
            if("".equals(ed1.getText().toString()) || "".equals(ed2.getText().toString()) || "".equals(ed3.getText().toString())){
                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                builder.setTitle("Error");
                builder.setPositiveButton("OK",null);
                builder.setMessage("All fields are mandatory");
                AlertDialog dialog=builder.create();
                dialog.show();
            }
            else
            {
                quiz = new Quiz();
                quiz.code = ed1.getText().toString();
                quiz.title = ed2.getText().toString();
                quiz.description = ed3.getText().toString();
                //TODO: de refacut aceatsa sectiune
//                if(sw.isChecked()){
//                    quiz.visiblle = true;
//                }
//                else{
//                    quiz.visiblle = false;
//                }
                quiz.visiblle=true;
               // quiz.option = Option.Individual;

                Intent intent=new Intent(this,AddQuestionActivity.class);
                startActivity(intent);
            }
        }

    }
}
