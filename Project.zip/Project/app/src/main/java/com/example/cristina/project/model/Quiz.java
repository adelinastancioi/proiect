package com.example.cristina.project.model;

import java.io.Serializable;
import java.util.ArrayList;




public class Quiz implements Serializable {
    public String code;
    public String title;
    public String description;
    public boolean visiblle;
    public ArrayList<Question> questionList;




    public String toString(){
        return this.title+"\n"+this.description+"\n"+questionList.toString();

    }

    public Quiz(){
        this.questionList = new ArrayList<>();
    }


}
