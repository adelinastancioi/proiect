package com.example.cristina.project.helpers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.cristina.project.contracts.DataBaseContract;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

public class DataBaseHelper extends SQLiteOpenHelper {

    public DataBaseHelper(@Nullable Context context)
    {
        super(context, DataBaseContract.DB_NAME,
                null, DataBaseContract.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                DataBaseContract.ImageTable.CREATE_TABLE);

        sqLiteDatabase.execSQL(
                DataBaseContract.TestTable.CREATE_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.QuestionTable.CREATE_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TestQuestionXRef.CREATE_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TeacherTable.CREATE_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.StudentTable.CREATE_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TestTeacherStudentXRef.CREATE_TABLE);





    }



    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(
                DataBaseContract.ImageTable.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TestTable.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.QuestionTable.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TestQuestionXRef.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TeacherTable.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.StudentTable.DROP_TABLE);
        sqLiteDatabase.execSQL(
                DataBaseContract.TestTeacherStudentXRef.DROP_TABLE);
    }

}
