package com.example.cristina.project.adapters;

@interface NonNull {
}
