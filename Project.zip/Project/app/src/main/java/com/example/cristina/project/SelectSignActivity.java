package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SelectSignActivity extends AppCompatActivity {
    private Button btnLogin, btnRegister;
    private String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_sign);

        user = getIntent().getStringExtra("USER");

        btnLogin = (Button)findViewById(R.id.loginButton);
        btnRegister = (Button)findViewById(R.id.registerButton);


        btnRegister.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if(user == null){
                    Toast.makeText(v.getContext(), "No profile selected!",
                            Toast.LENGTH_LONG).show();
                }
                else{
                    if(user.equals("student")){
                        Intent intent = new Intent(v.getContext(),StudentSignUpActivity.class);
                        startActivity(intent);
                    }
                    if(user.equals("teacher")){
                        Intent intent = new Intent(v.getContext(),TeacherSignUp.class);
                        startActivity(intent);
                    }


                }
            }
        });
}



    public void navigateToLogInActivity(View v){
        Intent intent = new Intent(this, LogInActivity.class);
        startActivity(intent);
    }


//    public void navigateToSignUp(View v) {
//        Intent intent = new Intent(this, TeacherSignUp.class);
//        startActivity(intent);
//    }
//
//    public void navigateToSignUpStudent(View v){
//        Intent intent = new Intent(this, StudentSignUpActivity.class);
//        startActivity(intent);
//    }


//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if(requestCode == 1 && resultCode == RESULT_OK) {
//            user = (String)data.getSerializableExtra("USER");
//            }
//    }


//    public void navigateToSignUp(View v){
//        Intent intent = new Intent(this,TeacherSignUp.class);
//        startActivity(intent);
//    }
}
