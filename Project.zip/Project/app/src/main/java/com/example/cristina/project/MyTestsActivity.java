package com.example.cristina.project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MyTestsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tests);
    }
}
