package com.example.cristina.project;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.IntentCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.cristina.project.adapters.QuestionCustomAdapter;
import com.example.cristina.project.model.Question;
import com.example.cristina.project.model.Quiz;

import java.util.ArrayList;

public class TestReviewActivity extends AppCompatActivity {

    ListView listview;
    private static QuestionCustomAdapter adapter;
    //public static ArrayList<Question> questionArrayList = null;
    private static Quiz quiz;
    TextView titleTextView, testCodeTextView, testDescTextView, testVisibilityTextView;
    FloatingActionButton fab,fab1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_review);
        quiz = AddQuestionActivity.getQuiz();

        titleTextView = (TextView)findViewById(R.id.testTitleTextView);
        titleTextView.setText(quiz.title);

        testCodeTextView = (TextView)findViewById(R.id.testCodeTextView);
        testCodeTextView.setText(quiz.code);

        testDescTextView = (TextView)findViewById(R.id.testDescTextView);
        testDescTextView.setText(quiz.description);

fab=findViewById(R.id.back);
fab1=findViewById(R.id.back2);



        listview = (ListView)findViewById(R.id.testReviewListView);
       // questionArrayList = AddQuestionActivity.getList();
        QuestionCustomAdapter questionAdaper = new QuestionCustomAdapter(this, quiz.questionList);
        listview.setAdapter(questionAdaper);



        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Question question = quiz.questionList.get(position);

            }
        });
    }

    public void back(View view){
        Intent intent=new Intent(this,QuestionsPortfolio.class);
        startActivity(intent);
    }

    public void back2(View view){
        Intent intent=new Intent(this, TeacherProfileActivity.class);
       // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK  | Intent.FLAG_ACTIVITY_CLEAR_TASK);
      //  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }


}







