package com.example.cristina.project.contracts;
import android.provider.BaseColumns;

import com.example.cristina.project.model.Question;

public class DataBaseContract {
    public static final String DB_NAME ="game.db";
    public static final int DB_VERSION=1;

    public class ImageTable implements BaseColumns{
        public static final String TABLE_NAME_IMAGE="images";
        public static final String COLUMN_NAME_IDIMAGE="idImage";
        public static final String COLUMN_NAME_IMAGE="image";

        public static final String CREATE_TABLE=
                "CREATE TABLE " + TABLE_NAME_IMAGE +" (" + COLUMN_NAME_IDIMAGE +"TEXT PRIMARY KEY," +
                        COLUMN_NAME_IMAGE +" TEXT )";
        public static final String DROP_TABLE=
                "DROP TABLE IF EXISTS " + TABLE_NAME_IMAGE;

    }
public class TestTable implements  BaseColumns
{
    public static final String TABLE_NAME_TEST="tests";
public static final  String COLUMN_NAME_COD="cod";
public static final String COLUMN_NAME_TITLE="title";
public static final String COLUMN_NAME_CATEGORY="category";
public static final String COLUMN_NAME_DESCRIPTION="description";
public static final String COLUMN_NAME_OPTION="option";
public static final String COLUMN_NAME_VISIBILITY="visibility";
public static final String COLUMN_NAME_IDIMAGE="idImage";
public static final String COLUMN_NAME_CREAREDATE="create_date";
public static final String COLUMN_NAME_IDTEACHER="idTeacher";



    public static final String CREATE_TABLE=
        "CREATE TABLE" + TABLE_NAME_TEST + " (" + COLUMN_NAME_COD + " INTEGER PRIMARY KEY, " +
                                            COLUMN_NAME_TITLE + " TEXT, " +
                                            COLUMN_NAME_CATEGORY + " TEXT, " +
                                            COLUMN_NAME_DESCRIPTION + " TEXT, " +
                                            COLUMN_NAME_OPTION +" TEXT, " +
                                            COLUMN_NAME_VISIBILITY +" BOOLEAN, " +

                COLUMN_NAME_CREAREDATE +" TEXT, " +
                "FOREIGN KEY(idTeacher) REFERENCES " +TeacherTable.TABLE_NAME_TEACHER + "(idTeacher)" +
                "FOREIGN KEY(idImage) REFERENCES " + ImageTable.TABLE_NAME_IMAGE + "(idImage) )";
public static final String DROP_TABLE="DROP TABLE IF EXISTS " + TABLE_NAME_TEST;



}



    public class QuestionTable implements BaseColumns{
    public static final String TABLE_NAME_QUESTION="questions";
    public static final String COLUMN_NAME_IDQUESTION="idQuestion";
    public static final String COLUMN_NAME_QUESTION="question";
    public static final String COLUMN_NAME_ANSWER1="answer1";
    public static final String COLUMN_NAME_ANSWER2="answer2";
    public static final String COLUMN_NAME_ANSWER3="answer3";
    public static final String COLUMN_NAME_CORRECT_ANSWER="correct_answer";
    public static final String COLUMN_NAME_CATEGORY="category";
    public static final String COLUMN_NAME_TIMER="timer";
    public static final  String COLUMN_NAME_COD="cod";
    public static final String COLUMN_NAME_IDIMAGE="idImage";

    public static final String CREATE_TABLE=
            "CREATE TABLE "+ TABLE_NAME_QUESTION + " (" + COLUMN_NAME_IDQUESTION + "INTEGER PRIMARY KEY" +
                    COLUMN_NAME_QUESTION + " TEXT, "  +
                    COLUMN_NAME_ANSWER1 +" TEXT, " +
                    COLUMN_NAME_ANSWER2 +" TEXT, " +
                    COLUMN_NAME_ANSWER3 +" TEXT, " +
                    COLUMN_NAME_CORRECT_ANSWER +" TEXT, " +
                    COLUMN_NAME_CATEGORY +" TEXT, "  +
                    COLUMN_NAME_TIMER +" TEXT ," +
                    "FOREIGN KEY(cod) REFERENCES " + TestTable.TABLE_NAME_TEST+ "(cod)" +
                    "FOREIGN KEY(idImage) REFERENCES " + ImageTable.TABLE_NAME_IMAGE + "(idImage) )";


    public static final String DROP_TABLE=
            "DROP TABLE IF EXISTS "+ TABLE_NAME_QUESTION;


    }



public class TestQuestionXRef implements BaseColumns {
        public static final String TABLE_NAME_REF= "TestQuestionXRef";
        public static final String COLUMN_NAME_IDREF="idTestQuestionRef";
        public static final String COLUMN_NAME_COD="cod";
        public static final String COLUMN_NAME_ID_QUESTION="idQuestion";
        public static final String CREATE_TABLE=
                "CREATE TABLE " + TABLE_NAME_REF + " (" +COLUMN_NAME_IDREF +" INTEGER PRIMARY KEY, " + "FOREIGN KEY(cod) REFERENCES " + TestTable.TABLE_NAME_TEST+ "(cod)" +
                        "FOREIGN KEY(idQuestion) REFERENCES " + QuestionTable.TABLE_NAME_QUESTION+ "(idQuestion) )" ;
        public static final String DROP_TABLE="DROP TABLE IF EXISTS " + TABLE_NAME_REF;

}
public class TeacherTable implements BaseColumns{
public static final String TABLE_NAME_TEACHER="teachers";
public static final String COLUMN_NAME_ID_TEACHER="idTeacher";
public static final String COLUMN_NAME_NAME="first_name";
public static final String COLUMN_NAME_SURNAME="surname";
public static final String COLUMN_NAME_EMAIL="email";
public static final String COLUMN_NAME_PASSWORD="password";
public static final String COLUMN_NAME_UNIVERSITY="university";
public static final String COLUMN_NAME_DISCIPLINES="disciplines";
public static final String COLUMN_NAME_IMAGE="idImage";


public static final String CREATE_TABLE=
        "CREATE TABLE  " + TABLE_NAME_TEACHER + " (" +
                COLUMN_NAME_ID_TEACHER + " TEXT PRIMARY KEY, " +
                COLUMN_NAME_NAME +" TEXT, " +
                COLUMN_NAME_SURNAME +" TEXT, " +
                COLUMN_NAME_EMAIL + " TEXT, " +
                COLUMN_NAME_PASSWORD + " TEXT, "+
                COLUMN_NAME_UNIVERSITY + " TEXT, " +
                COLUMN_NAME_DISCIPLINES + " TEXT, " +
                "FOREIGN KEY(idImage) REFERENCES " + ImageTable.TABLE_NAME_IMAGE + "(idImage) )";

public static final String DROP_TABLE =
        "DROP TABLE IF EXISTS " + TABLE_NAME_TEACHER;

}
public class StudentTable implements BaseColumns{
    public static final String TABLE_NAME_STUDENT="students";
    public static final String COLUMN_NAME_ID_STUDENT="idStudent";
    public static final String COLUMN_NAME_NAME="name";
    public static final String COLUMN_NAME_SURNAME="surname";
    public static final String COLUMN_NAME_PASSWORD="password";
    public static final String COLUMN_NAME_IMAGE="image";
    public static final String COLUMN_NAME_GLOBAL_SCORE="globalScore";

    public static final String CREATE_TABLE= " CREATE TABLE " + TABLE_NAME_STUDENT +  " (" +
            COLUMN_NAME_ID_STUDENT + " TEXT PRIMARY KEY, "+
            COLUMN_NAME_NAME + " TEXT, " +
            COLUMN_NAME_SURNAME + " TEXT, " +
            COLUMN_NAME_PASSWORD + " TEXT, " +
            COLUMN_NAME_GLOBAL_SCORE + " INTEGER, " +
            "FOREIGN KEY(idImage) REFERENCES " + ImageTable.TABLE_NAME_IMAGE + "(idImage) )";
    public static final String DROP_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_NAME_STUDENT;


}
public class TestTeacherStudentXRef implements  BaseColumns
{
    public static final String TABLE_NAME_TTSREF="TestTeacherStudentXRef";
    public static final String COLUMN_NAME_ID="id";
    public static final String COLUMN_NAME_ID_TEACHER="idTeacher";
    public static final String COLUMN_NAME_COD_TEST="cod";
    public static final String COLUMN_NAME_TRIALS_LEFT="trials_left";
    public static final String COLUMN_NAME_ATTENDING_DATE="attenting_date";
    public static final String COLUMN_NAME_SCORE="score";

    public static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_TTSREF + " (" +
            COLUMN_NAME_ID + " INTEGER PRIMARY KEY, " +
            COLUMN_NAME_TRIALS_LEFT + " INTEGER, " +
            COLUMN_NAME_ATTENDING_DATE + " TEXT, " +
            COLUMN_NAME_SCORE + " INTEGER, " +
            "FOREIGN KEY(cod) REFERENCES " + TestTable.TABLE_NAME_TEST+ "(cod)" +
            "FOREIGN KEY(idTeacher) REFERENCES " + TeacherTable.TABLE_NAME_TEACHER + "(idTeacher) )";

    public static final String DROP_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_NAME_TTSREF;

}
}


