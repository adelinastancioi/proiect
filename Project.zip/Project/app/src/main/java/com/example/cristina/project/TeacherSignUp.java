package com.example.cristina.project;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TeacherSignUp extends AppCompatActivity {


    private EditText ed1, ed2, ed3, ed4, ed5, ed6;
    private Button bt1, bt2;
private CheckBox ck1,ck2,ck3,ck4,ck5,ck6,ck7,ck8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_sign_up);
        ed1 = findViewById(R.id.Prenume);
        ed2 = findViewById(R.id.Nume);
        ed3 = findViewById(R.id.Email);
        ed4 = findViewById(R.id.Password);
        ed5 = findViewById(R.id.Password2);
        ed6 = findViewById(R.id.School);
        bt1 = (Button) findViewById(R.id.loginProf);
        bt2 = (Button) findViewById(R.id.btnJoin);

       ck1 = (CheckBox)findViewById(R.id.ck1);
       ck2= (CheckBox)findViewById(R.id.ck2);
        ck3 = (CheckBox)findViewById(R.id.ck3);
       ck4 = (CheckBox)findViewById(R.id.ck4);
        ck5 = (CheckBox)findViewById(R.id.ck5);
        ck6= (CheckBox)findViewById(R.id.ck6);
        ck7= (CheckBox)findViewById(R.id.ck7);
        ck8= (CheckBox)findViewById(R.id.ck8);





    }
    public static boolean isEmailValid(String email) {
        boolean isValid = false;

        String expression = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()) {
            isValid = true;
        }
        return isValid;
    }
    public void join(View v) {
        if (ed1 != null && ed2 != null && ed3 != null && ed5 != null && ed6 != null) {
            if ("".equals(ed1.getText().toString()) ||
                    "".equals(ed2.getText().toString()) || "".equals(ed3.getText().toString()) || "".equals(ed4.getText().toString()) || "".equals(ed5.getText().toString()) ||
                    "".equals(ed6.getText().toString())
                    )



            {
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(this);
                builder.setTitle(R.string.error_text);
                builder.setMessage("All fields are mandatory!");
                builder.setPositiveButton("OK", null);
                AlertDialog dialog = builder.create();
                dialog.show();
            }

//
            else{
                if (isEmailValid(ed3.getText().toString().trim()) == false) {
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(this);
                    builder.setTitle(R.string.error_text);
                    builder.setMessage("Invalid Email");
                    builder.setPositiveButton("OK", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }

                if (isPasswdValid(ed4.getText().toString().trim()) == false) {
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(this);
                    builder.setTitle(R.string.error_text);
                    builder.setMessage("Invalid Password(Minimum 4 characters, at least one uppercase letter and one number and a special character)");
                    builder.setPositiveButton("OK", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }
                String u = ed4.getText().toString();
                String p = ed5.getText().toString();
                if ( ! u.equals( p )){
                    AlertDialog.Builder builder =
                            new AlertDialog.Builder(this);
                    builder.setTitle(R.string.error_text);
                    builder.setMessage("Not the same password as the previous one    "  + ed4.getText() + "     " + ed5.getText());
                    builder.setPositiveButton("OK", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }
                Intent intent=new Intent(TeacherSignUp.this,TeacherProfileActivity.class);
                intent.putExtra("prenume", ed1.getText().toString());
                intent.putExtra("nume",ed2.getText().toString());
                intent.putExtra("ck1", ck1.isChecked());
                intent.putExtra("ck2", ck2.isChecked());
                intent.putExtra("ck3", ck3.isChecked());
                intent.putExtra("ck4", ck4.isChecked());
                intent.putExtra("ck5", ck5.isChecked());
                intent.putExtra("ck6", ck6.isChecked());
                intent.putExtra("ck7", ck7.isChecked());
                intent.putExtra("ck8", ck8.isChecked());
                intent.putExtra("university",ed6.getText().toString());
                startActivity(intent);
              startActivity(intent);
            }


        }


    }


    public void logIn(View v)
    {
        Intent intent=new Intent(TeacherSignUp.this,LogInActivity.class);
        startActivity(intent);


    }
    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
    public static boolean isPasswdValid(String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }


}
