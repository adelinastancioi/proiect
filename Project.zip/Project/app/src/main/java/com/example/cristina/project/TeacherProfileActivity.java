package com.example.cristina.project;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;

public class TeacherProfileActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ImageView targetImage;
    ImageView menuAvatar;
    TextView tv1,tv2,tv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.importPhotoButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        Intent intent = getIntent();
        String user_name = intent.getStringExtra("nume");
        String user_name2 = intent.getStringExtra("prenume");
        String university = intent.getStringExtra("university");
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View hView = navigationView.getHeaderView(0);
        TextView nav_user = (TextView) hView.findViewById(R.id.NumeProf);

        nav_user.setText(user_name + " " + user_name2);
        TextView nav_uni = (TextView) hView.findViewById(R.id.EmailProf);
        nav_uni.setText(university);


        Button buttonLoadImage = (Button) findViewById(R.id.loadPhotoButton);
        targetImage = (ImageView) findViewById(R.id.teacherAvatar);
        menuAvatar = (ImageView) findViewById(R.id.menuAvatar);
        tv1 = (TextView) findViewById(R.id.profileUsernameEditText);

        buttonLoadImage.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 0);
            }

        });


        tv1.setText(user_name + " " + user_name2);

        try {

            Boolean check1 = getIntent().getExtras().getBoolean("ck1");
            Boolean check2 = getIntent().getExtras().getBoolean("ck2");
            Boolean check3 = getIntent().getExtras().getBoolean("ck3");
            Boolean check4 = getIntent().getExtras().getBoolean("ck4");
            Boolean check5 = getIntent().getExtras().getBoolean("ck5");
            Boolean check6 = getIntent().getExtras().getBoolean("ck6");
            Boolean check7 = getIntent().getExtras().getBoolean("ck7");
            Boolean check8 = getIntent().getExtras().getBoolean("ck8");
            tv2 = findViewById(R.id.profileDescriptionEditText);
            String text = "";
            if (check1) {
                text = "Tehnologii Web\n";

            }
            if (check2) {
                text = text + "DAM\n";
                //tv2.setText("DAM");
            }
            if (check3) {
                text = text + "Retele\n";
            }
            if (check4) {
                text = text + "Analiza Datelor\n";
            }
            if (check5) {
                text = text + "POO\n";
            }
            if (check6) {
                text = text + "Java\n";
            }
            if (check7) {
                text = text + "SDD\n";
            }
            if (check8) {
                text = text + "PAW\n";
            }
            tv2.setText(text);
        }catch (Exception e){

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK){
            Uri targetUri = data.getData();
            Bitmap bitmap;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(targetUri));
                targetImage.setImageBitmap(bitmap);


            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.teacher_profile, menu);
        return true;
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addQuestion(View v){
        Intent intent = new Intent(this,CreateQuizTest.class);
        startActivity(intent);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_myTests) {
            Intent intent = new Intent(this, MyTestsActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_questionsLibrary) {
            Intent intent = new Intent(this, QuestionsPortfolio.class);
            startActivity(intent);

        } else if (id == R.id.nav_studentsList) {
            Intent intent = new Intent(this, GroupsActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_reports) {

        } else if (id == R.id.nav_feedback) {
            Intent intent = new Intent(this, Feedbacks.class);
            startActivity(intent);

        } else if (id == R.id.nav_logout) {
            Intent intent = new Intent(this,TeacherOrStudent.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
