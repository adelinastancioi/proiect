package com.example.cristina.project.workers;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Base64;
import android.util.Log;

import com.example.cristina.project.GroupsActivity;
import com.example.cristina.project.StudentsListActivity;
import com.example.cristina.project.model.Student;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class StudentWorker extends AsyncTask<String, Integer, List<Student>> {

    public static ArrayList<Student>studentsList=new ArrayList<>();



    @Override
    protected List<Student> doInBackground(String... strings) {

        if (strings == null || strings.length == 0) {
            ArrayList<Student> list = new ArrayList<>();
            Student student = new Student();
            student.firstName = "Cristina";
            student.lastName = "Sosoi";
            student.grupa = 1074;
            student.scorMediu = 10;
            list.add(student);
            return list;
        } else {

            studentsList = new ArrayList<>();
            String grupa = strings[0];
            String address = String.format("https://api.myjson.com/bins/%s", grupa);
            HttpURLConnection connection = null;

            try {
                URL url = new URL(address);
                connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                String result = stringBuilder.toString();
                Log.d("JSON", result);
                JSONArray jsonArray = new JSONArray(result);

                reader.close();

                for (int i = 0; i < jsonArray.length(); i++) {
                    try {
                        Student student = new Student();
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        student.firstName = jsonObject.getString("prenume");
                        student.lastName = jsonObject.getString("nume");
                        student.email = jsonObject.getString("email");
                        student.grupa = jsonObject.getInt("grupa");
                        student.scorMediu = jsonObject.getDouble("scorMediu");
                        studentsList.add(student);
                    }
                    catch(Exception e) {
                        e.printStackTrace();
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }

            return studentsList;
        }
    }


    @Override
    protected void onPostExecute(List<Student> students) {
        StudentsListActivity.studentsList.clear();
        StudentsListActivity.studentsList.addAll(students);
        StudentsListActivity.studentAdapter.notifyDataSetChanged();
        StudentsListActivity.studentAdapter.notifyDataSetChanged();
        StudentsListActivity.studentAdapter.notifyDataSetChanged();
        StudentsListActivity.studentAdapter.notifyDataSetChanged();
        StudentsListActivity.studentAdapter.notifyDataSetChanged();
        StudentsListActivity.studentAdapter.notifyDataSetChanged();


//        DatabaseHelper helper = new DatabaseHelper(_context);
//        SQLiteDatabase db = helper.getWritableDatabase();
//
//        db.execSQL("DELETE FROM " + DatabaseContract.ForecastTable.TABLE_NAME +
//                " WHERE " + DatabaseContract.ForecastTable.COLUMN_NAME_LOCATION +
//                " = '" + _location + "'");
//
//        for(WeatherCondition cond : weatherConditions) {
//            ContentValues cv = new ContentValues();
//            cv.put(DatabaseContract.ForecastTable.COLUMN_NAME_LOCATION,
//                    _location);
//            SimpleDateFormat dateFormat =
//                    new SimpleDateFormat("yyyy-MM-dd");
//            cv.put(DatabaseContract.ForecastTable.COLUMN_NAME_DAY,
//                    dateFormat.format(cond.date));
//            cv.put(DatabaseContract.ForecastTable.COLUMN_NAME_TEMPERATURE,
//                    cond.temperature);
//            cv.put(DatabaseContract.ForecastTable.COLUMN_NAME_DESCRIPTION,
//                    cond.description);
//
//            ByteArrayOutputStream out = new ByteArrayOutputStream();
//            cond.image.compress(Bitmap.CompressFormat.PNG, 100, out);
//            String base64 = Base64.encodeToString(out.toByteArray(),
//                    Base64.DEFAULT);
//            cv.put(DatabaseContract.ForecastTable.COLUMN_NAME_IMAGE,
//                    base64);
//            db.insert(DatabaseContract.ForecastTable.TABLE_NAME,
//                    null, cv);






    }

}





